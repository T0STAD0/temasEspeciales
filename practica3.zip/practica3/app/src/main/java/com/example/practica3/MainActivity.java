package com.example.practica3;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // ── Componentes de entrada ────────────────────────────────────────────────
    private EditText  txtHijos;
    private EditText  txtHijosEscolares;
    private RadioGroup rgEstadoCivil;
    private RadioButton rbViuda;
    private RadioButton rbOtro;

    // ── Componentes de salida (resultados) ───────────────────────────────────
    private TextView txtSubsidioHijos;
    private TextView txtSubsidioEscolar;
    private TextView txtSubsidioViudez;
    private TextView txtTotal;

    // ────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de componentes de entrada
        txtHijos          = findViewById(R.id.txtHijos);
        txtHijosEscolares = findViewById(R.id.txtHijosEscolares);
        rgEstadoCivil     = findViewById(R.id.rgEstadoCivil);
        rbViuda           = findViewById(R.id.rbViuda);
        rbOtro            = findViewById(R.id.rbOtro);

        // Inicialización de componentes de salida
        txtSubsidioHijos   = findViewById(R.id.txtSubsidioHijos);
        txtSubsidioEscolar = findViewById(R.id.txtSubsidioEscolar);
        txtSubsidioViudez  = findViewById(R.id.txtSubsidioViudez);
        txtTotal           = findViewById(R.id.txtTotal);
    }

    // ── Método vinculado al botón "Procesar Datos" (android:onClick) ─────────
    /**
     * Calcula y muestra los subsidios según las reglas:
     *
     *  1. Subsidio por número de hijos:
     *       0 – 2  hijos  → $1 700
     *       3 – 5  hijos  → $1 900
     *       > 5    hijos  → $1 200
     *
     *  2. Subsidio escolar: $200 × hijos en edad escolar
     *
     *  3. Subsidio por viudez: +$800 si la madre es viuda
     */
    public void procesar_subsidio(View view) {

        // ── Validación básica de campos vacíos ────────────────────────────
        String strHijos          = txtHijos.getText().toString().trim();
        String strHijosEscolares = txtHijosEscolares.getText().toString().trim();

        if (strHijos.isEmpty()) {
            Toast.makeText(this,
                    "Por favor, ingrese el número de hijos.",
                    Toast.LENGTH_SHORT).show();
            txtHijos.requestFocus();
            return;
        }

        if (strHijosEscolares.isEmpty()) {
            Toast.makeText(this,
                    "Por favor, ingrese el número de hijos en edad escolar.",
                    Toast.LENGTH_SHORT).show();
            txtHijosEscolares.requestFocus();
            return;
        }

        // ── Conversión de las entradas a enteros ──────────────────────────
        int numHijos          = Integer.parseInt(strHijos);
        int numHijosEscolares = Integer.parseInt(strHijosEscolares);

        // Validación lógica: los escolares no pueden superar el total de hijos
        if (numHijosEscolares > numHijos) {
            Toast.makeText(this,
                    "Los hijos en edad escolar no pueden ser más que el total de hijos.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // ── 1. Cálculo del subsidio por número de hijos ───────────────────
        int subsidioHijos;

        if (numHijos <= 2) {
            // 0 a 2 hijos → $1 700
            subsidioHijos = 1700;
        } else if (numHijos <= 5) {
            // Más de 2 hasta 5 hijos → $1 900
            subsidioHijos = 1900;
        } else {
            // Más de 5 hijos → $1 200
            subsidioHijos = 1200;
        }

        // ── 2. Cálculo del subsidio escolar ($200 por cada hijo escolar) ──
        int subsidioEscolar = numHijosEscolares * 200;

        // ── 3. Cálculo del subsidio por viudez ────────────────────────────
        int subsidioViudez = 0;

        if (rbViuda.isChecked()) {
            subsidioViudez = 800;
        }

        // ── Cálculo del total ─────────────────────────────────────────────
        int total = subsidioHijos + subsidioEscolar + subsidioViudez;

        // ── Actualización de los TextView con los resultados ──────────────
        txtSubsidioHijos.setText(  formatPesos(subsidioHijos));
        txtSubsidioEscolar.setText(formatPesos(subsidioEscolar));
        txtSubsidioViudez.setText( formatPesos(subsidioViudez));
        txtTotal.setText(          formatPesos(total));
    }

    // ── Utilidad: formato de moneda ───────────────────────────────────────────
    /**
     * Devuelve el valor formateado como "$1,700.00"
     */
    private String formatPesos(int monto) {
        return String.format("$%,d.00", monto);
    }
}