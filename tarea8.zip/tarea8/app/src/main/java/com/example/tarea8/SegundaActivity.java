package com.example.tarea8;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SegundaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        TextView tvNombreCompleto = findViewById(R.id.tvNombreCompleto);

        String nombre = getIntent().getStringExtra("NOM");
        String paterno = getIntent().getStringExtra("PAT");
        String materno = getIntent().getStringExtra("MAT");

        tvNombreCompleto.setText("Bienvenido:\n" + nombre + " " + paterno + " " + materno);
    }
}