package com.example.tarea8;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etNombre = findViewById(R.id.etNombre);
        EditText etPaterno = findViewById(R.id.etPaterno);
        EditText etMaterno = findViewById(R.id.etMaterno);
        ImageButton btnEnviar = findViewById(R.id.btnEnviar);

        btnEnviar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SegundaActivity.class);
            intent.putExtra("NOM", etNombre.getText().toString());
            intent.putExtra("PAT", etPaterno.getText().toString());
            intent.putExtra("MAT", etMaterno.getText().toString());
            startActivity(intent);
        });
    }
}