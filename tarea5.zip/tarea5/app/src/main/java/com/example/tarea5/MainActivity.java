package com.example.tarea5;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText; // <--- ESTA ES LA LÍNEA QUE FALTA
import android.widget.Button;   // <--- ESTA TAMBIÉN LA NECESITARÁS
import android.content.Intent;  // <--- Y ESTA PARA EL INTENT

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etNombre = findViewById(R.id.etNombre);
        Button btnEnviar = findViewById(R.id.btnEnviar);

        btnEnviar.setOnClickListener(v -> {
            String nombre = etNombre.getText().toString();

            // Creamos el intent hacia la siguiente pantalla
            Intent intent = new Intent(MainActivity.this, SaludoActivity.class);
            intent.putExtra("MI_DATO", nombre); // Guardamos el nombre con una etiqueta
            startActivity(intent);
        });
    }
}