package com.example.tarea5;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SaludoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo); // Conecta con el diseño XML

        TextView tvSaludo = findViewById(R.id.tvSaludo);
        String nombre = getIntent().getStringExtra("MI_DATO");
        tvSaludo.setText("¡Hola, " + nombre + "!");
    }
}