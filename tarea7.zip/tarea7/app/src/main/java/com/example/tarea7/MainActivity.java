package com.example.tarea7;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etNombre = findViewById(R.id.etNombre);
        EditText etPaterno = findViewById(R.id.etPaterno);
        EditText etMaterno = findViewById(R.id.etMaterno);
        Button btnEnviar = findViewById(R.id.btnEnviar);

        btnEnviar.setOnClickListener(v -> {
            // Creamos el Intent
            Intent intent = new Intent(MainActivity.this, SegundaActivity.class);

            // Pasamos cada dato con una llave distinta
            intent.putExtra("NOM", etNombre.getText().toString());
            intent.putExtra("PAT", etPaterno.getText().toString());
            intent.putExtra("MAT", etMaterno.getText().toString());

            startActivity(intent);
        });
    }
}