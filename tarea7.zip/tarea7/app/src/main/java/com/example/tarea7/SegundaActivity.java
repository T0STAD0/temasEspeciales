package com.example.tarea7;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SegundaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        TextView tvNombreCompleto = findViewById(R.id.tvNombreCompleto);

        // Recuperamos los datos usando las llaves NOM, PAT y MAT
        String nombre = getIntent().getStringExtra("NOM");
        String paterno = getIntent().getStringExtra("PAT");
        String materno = getIntent().getStringExtra("MAT");

        // Mostramos todo el nombre unido
        String resultado = "Bienvenido:\n" + nombre + " " + paterno + " " + materno;
        tvNombreCompleto.setText(resultado);
    }
}