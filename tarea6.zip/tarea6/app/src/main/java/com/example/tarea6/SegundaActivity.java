package com.example.tarea6;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SegundaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        TextView tvResultado = findViewById(R.id.tvResultado);
        String recibido = getIntent().getStringExtra("DATO");
        tvResultado.setText("Recibido: " + recibido);
    }
}