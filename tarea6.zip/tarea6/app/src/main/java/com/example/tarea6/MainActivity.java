package com.example.tarea6;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etTexto = findViewById(R.id.etTexto);
        Button btnIr = findViewById(R.id.btnIr);

        btnIr.setOnClickListener(v -> {
            String texto = etTexto.getText().toString();
            Intent intent = new Intent(this, SegundaActivity.class);
            intent.putExtra("DATO", texto);
            startActivity(intent);
        });
    }
}