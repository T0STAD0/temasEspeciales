package com.example.tarea10;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.EditText;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class ExtendedEditText extends EditText {
    // Definir los pinceles para el dibujo
    private Paint p1; // Fondo negro
    private Paint p2; // Texto blanco
    private float escala;

    public ExtendedEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        inicializacion();
    }

    public ExtendedEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        inicializacion();
    }

    public ExtendedEditText(Context context) {
        super(context);
        inicializacion();
    }
    private void inicializacion() {
        escala = getResources().getDisplayMetrics().density;

        // Fondo: Un gris oscuro semi-transparente en lugar de negro sólido
        p1 = new Paint(Paint.ANTI_ALIAS_FLAG);
        p1.setColor(Color.parseColor("#80000000")); // Negro con 50% de transparencia
        p1.setStyle(Paint.Style.FILL);

        // Texto: Un blanco más limpio
        p2 = new Paint(Paint.ANTI_ALIAS_FLAG);
        p2.setColor(Color.WHITE);
        p2.setTextSize(14 * escala); // Un poco más pequeño y elegante
        p2.setTextAlign(Paint.Align.CENTER); // Centrar el texto
        p2.setFakeBoldText(true); // Negrita
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float anchoRect = 35 * escala;
        float altoRect = 20 * escala;
        float margen = 5 * escala;

        // Rectángulo redondeado
        RectF rect = new RectF(this.getWidth() - anchoRect - margen,
                margen,
                this.getWidth() - margen,
                altoRect + margen);

        // Dibujar fondo con esquinas redondeadas (radio de 8dp)
        canvas.drawRoundRect(rect, 8 * escala, 8 * escala, p1);

        // Dibujar texto centrado en el rectángulo
        String contador = "" + this.getText().toString().length();
        canvas.drawText(contador, rect.centerX(), rect.centerY() + (6 * escala), p2);
    }
}
